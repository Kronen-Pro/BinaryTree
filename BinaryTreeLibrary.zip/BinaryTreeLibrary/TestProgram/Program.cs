﻿// Program 5 EC
// Zalimkhan Tkhagazitov 
// Dr. Andrew Wright 
// Date: 4/24/2019
// Due: 4/24/2019 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryTreeLibrary;

namespace TestProgram
{
    class Program // We created a TestProgram which uses our BinaryTreeLibrary and launches the Program
    {
        static void Main(string[] args)
        {
            Tree<int> _integer = new Tree<int>(); // Tree for integer
            Tree<double> _double = new Tree<double>(); // Tree for double
            Tree<string> _string = new Tree<string>(); // Tree for string 

            _integer.InsertNode(1);  // Insering value into the trees: Int
            _integer.InsertNode(10);
            _integer.InsertNode(2);
            _integer.InsertNode(3);
            _integer.InsertNode(9);
            _integer.InsertNode(4);
            _integer.InsertNode(6);
            _integer.InsertNode(5);
            _integer.InsertNode(7);
            _integer.InsertNode(8);
            

            _double.InsertNode(1.1); // Insering value into the trees: Double
            _double.InsertNode(2.2);
            _double.InsertNode(3.3);
            _double.InsertNode(4.4);
            _double.InsertNode(5.5);
            _double.InsertNode(6.6);
            _double.InsertNode(7.7);
            _double.InsertNode(8.8);
            _double.InsertNode(9.9);
            _double.InsertNode(10.10);


            _string.InsertNode("11"); // Insering value into the trees: String
            _string.InsertNode("12");
            _string.InsertNode("13");
            _string.InsertNode("14");
            _string.InsertNode("15");
            _string.InsertNode("16");
            _string.InsertNode("17");
            _string.InsertNode("18");
            _string.InsertNode("19");
            _string.InsertNode("20");


            
            _integer.PreorderTraversal(); // Outputing all the Traversals for all the trees
            Console.WriteLine("\n");
            _integer.InorderTraversal();
            Console.WriteLine("\n");
            _integer.PostorderTraversal();
            Console.WriteLine("\n");
            Console.WriteLine("\n");


            _double.PreorderTraversal();
            Console.WriteLine("\n");
            _double.InorderTraversal();
            Console.WriteLine("\n");
            _double.PostorderTraversal();
            Console.WriteLine("\n");
            Console.WriteLine("\n");


            _string.PreorderTraversal();
            Console.WriteLine("\n");
            _string.InorderTraversal();
            Console.WriteLine("\n");
            _string.PostorderTraversal();
            Console.WriteLine("\n");
            Console.WriteLine("\n");

            Console.ReadKey();












        }

        



    }
}
